/* Allegro datafile object indexes, produced by grabber v3.12 */
/* Datafile: c:\dgm\proj2\data.dat */
/* Date: Sun Nov 26 05:33:37 2000 */
/* Do not hand edit! */

#define A000                             0        /* BMP  */
#define A001                             1        /* BMP  */
#define A002                             2        /* BMP  */
#define A003                             3        /* BMP  */
#define A004                             4        /* BMP  */
#define A005                             5        /* BMP  */
#define A006                             6        /* BMP  */
#define A007                             7        /* BMP  */
#define A008                             8        /* BMP  */
#define PALETA                           9        /* PAL  */
#define ZDGMLOGO                         10       /* BMP  */
#define ZFONT                            11       /* FONT */
#define ZM01                             12       /* MIDI */
#define ZM02                             13       /* MIDI */
#define ZMBELLA                          14       /* MIDI */
#define ZMNOVI                           15       /* MIDI */
#define ZSBIP                            16       /* SAMP */
#define ZSBIP2                           17       /* SAMP */
#define ZSLOSE                           18       /* SAMP */
#define ZZLOGO                           19       /* BMP  */

