//
// SphereS v1.0
//
// by DGM
//
// OBS: Ae pessoal, desculpem se o c�digo parece meio "confuso", mas esse �
//      meu jeito de programar, n�o gosto de ficar dividindo um programa
//      pequeno como esse em trezentos arquivos...blz? :)
//
// Nota Atualizada: N�o vou mexer no codigo, vou deixar como estava,
// eu achei isso num de meus cds, po, velharia rlz :) nem tanto, mas esse �
// de 2000/2001, eu nem lembrava mais desse jogo :)
// essa musica do inicio � "A novidade", dos paralamas do sucesso, e a
// musica tosca que vcs ouvirao durante o decorrer do jogo foi feita por mim
// num trackeador midi, chamado MASSIVA. ehehehe
// t� incompleto, nao tem o sistema de recordes, mas t� ai :) e
// qualquer coisa, dgmdavid@bol.com.br para entrar em contato comigo. Flw!
//
// 2000/2001 by DGM

#pragma comment (lib,"alleg.lib")

#include "conio.h"
#include "stdio.h"
#include "allegro.h"
#include "stdlib.h"
#include "graficos.h"

DATAFILE *data;

FONT *font;

BITMAP *tela,*tela2,*tela3;

int pa[7][15];   // o tabuleiro das bolas
int pa2[7][15];  

int rx,ry,col,a,asom;

//**** DGM LOGO ****
void DGMLOGO() {
//**** Introdu��o com o logotipo DGM ****
  set_pallete(data[PALETA].dat);                fade_out(64);
  draw_sprite(screen,data[ZDGMLOGO].dat,0,0);
  fade_in(data[PALETA].dat,1);                  rest(4000);
  fade_out(1);
  clear(screen);
  clear(tela2);
  fade_in(data[PALETA].dat,64);
  rest(100);
}

//****
void endmsg()
{
 unload_datafile(data);
 remove_timer();
 allegro_exit();
 printf("\n\r Sugest�es, Cr�ticas, D�vidas? \n\r Mande um e-mail para : dgm@ieg.com.br \n\r Home Page : www.dgm.hpg.ig.com.br \n\r\n\r by DGM \n\r\n\r");
 exit(1);
}

//****
void sombral(unsigned char *mesg, int x, int y)
{
 textout(tela,data[ZFONT].dat,mesg, x-1,y,87);
 textout(tela,data[ZFONT].dat,mesg, x+1,y,87);
 textout(tela,data[ZFONT].dat,mesg, x,y-1,87);
 textout(tela,data[ZFONT].dat,mesg, x,y+1,87);
 textout(tela,data[ZFONT].dat,mesg, x-1,y-1,87);
 textout(tela,data[ZFONT].dat,mesg, x-1,y+1,87);
 textout(tela,data[ZFONT].dat,mesg, x+1,y-1,87);
 textout(tela,data[ZFONT].dat,mesg, x+1,y+1,87);
 textout(tela,data[ZFONT].dat,mesg, x,y,103);
}

//****
void sombralc(unsigned char *mesg, int y,int s)
{
 if(s==1){
  textout(tela,data[ZFONT].dat,mesg, (rx/2)-(text_length(data[ZFONT].dat,mesg)/2)-1,y,87);
  textout(tela,data[ZFONT].dat,mesg, (rx/2)-(text_length(data[ZFONT].dat,mesg)/2)+1,y,87);
  textout(tela,data[ZFONT].dat,mesg, (rx/2)-(text_length(data[ZFONT].dat,mesg)/2),y-1,87);
  textout(tela,data[ZFONT].dat,mesg, (rx/2)-(text_length(data[ZFONT].dat,mesg)/2),y+1,87);
  textout(tela,data[ZFONT].dat,mesg, (rx/2)-(text_length(data[ZFONT].dat,mesg)/2)-1,y-1,87);
  textout(tela,data[ZFONT].dat,mesg, (rx/2)-(text_length(data[ZFONT].dat,mesg)/2)-1,y+1,87);
  textout(tela,data[ZFONT].dat,mesg, (rx/2)-(text_length(data[ZFONT].dat,mesg)/2)+1,y-1,87);
  textout(tela,data[ZFONT].dat,mesg, (rx/2)-(text_length(data[ZFONT].dat,mesg)/2)+1,y+1,87);
 }
 if(s==2){
  textout(tela,data[ZFONT].dat,mesg, (rx/2)-(text_length(data[ZFONT].dat,mesg)/2)-1,y,57);
  textout(tela,data[ZFONT].dat,mesg, (rx/2)-(text_length(data[ZFONT].dat,mesg)/2)+1,y,57);
  textout(tela,data[ZFONT].dat,mesg, (rx/2)-(text_length(data[ZFONT].dat,mesg)/2),y-1,57);
  textout(tela,data[ZFONT].dat,mesg, (rx/2)-(text_length(data[ZFONT].dat,mesg)/2),y+1,57);
  textout(tela,data[ZFONT].dat,mesg, (rx/2)-(text_length(data[ZFONT].dat,mesg)/2)-1,y-1,57);
  textout(tela,data[ZFONT].dat,mesg, (rx/2)-(text_length(data[ZFONT].dat,mesg)/2)-1,y+1,57);
  textout(tela,data[ZFONT].dat,mesg, (rx/2)-(text_length(data[ZFONT].dat,mesg)/2)+1,y-1,57);
  textout(tela,data[ZFONT].dat,mesg, (rx/2)-(text_length(data[ZFONT].dat,mesg)/2)+1,y+1,57);
 }
 textout(tela,data[ZFONT].dat,mesg, (rx/2)-(text_length(data[ZFONT].dat,mesg)/2),y,103);
}

//**** Exibe os cr�ditos do jogo ****
void creditos() {
 fade_out(1);
 clear_to_color(tela,255);
 draw_sprite(tela,data[ZZLOGO].dat,320-(610/2),240-(257/2));
 sombralc("SphereS v1.0 - by DGM",10,1 );
  sombralc("Desenvolvimento geral :",45,1 );
   sombralc("David Gustavo Maziero - DGM", 60,0);
  sombralc("Agradecimentos :",80,1 );
   sombralc("Delorie DJGPP - compilador C/C++",95,0);
   sombralc("Allegro Game Library",110,0);
   sombralc("Jasc Paint Shop Pro 6.0",125,0);
 blit(tela,screen,0,0,0,0,rx,ry);
 fade_in(data[PALETA].dat,1);
 clear_keybuf();
 readkey();
 fade_out(1);
}

//**** Mostra as instru��es do jogo ****
void instru() {
 int x; //,y;
 fade_out(1);
 clear_to_color(tela,255);
 draw_sprite(tela,data[ZZLOGO].dat,320-(610/2),480-257);
 sombralc("SphereS v1.0 - by DGM",10,1 );
 sombralc("Instrucoes Gerais do jogo",30,1 );

  textout(tela,data[ZFONT].dat,"Use as setas direita/esquerda para mover o cursor", 80,200,103);
  textout(tela,data[ZFONT].dat,"as setas cima/baixo para rolar a coluna, e espaco para rolar a linha", 80,215,103);

 for(x=0;x<4;x++) draw_sprite(tela,data[1].dat,35+(x*20),80 );
 textout(tela,data[ZFONT].dat,"Alinhe 4 bolas de mesma cor e ganhe 10 pontos", 125,80,103);
 for(x=0;x<5;x++) draw_sprite(tela,data[2].dat,35+(x*20),110 );
 textout(tela,data[ZFONT].dat,"Alinhe 5 bolas de mesma cor e ganhe 15 pontos", 145,110,103);
 for(x=0;x<6;x++) draw_sprite(tela,data[3].dat,35+(x*20),140 );
 textout(tela,data[ZFONT].dat,"Alinhe 6 bolas de mesma cor e ganhe 25 pontos", 165,140,103);
 for(x=0;x<7;x++) draw_sprite(tela,data[4].dat,35+(x*20),170 );
 textout(tela,data[ZFONT].dat,"Alinhe 7 bolas de mesma cor e ganhe 100 pontos", 185,170,103);
 blit(tela,screen,0,0,0,0,rx,ry);
 fade_in(data[PALETA].dat,1);
 clear_keybuf();
 readkey();
 fade_out(1);
}

int playgame();

//**** Coloca a tela inicial do jogo ****
void poenome() {
 int op;
 //int re;
 int x,y,a,bo,xx,pkey,somativo;
 somativo=0;
inicio:;
 fade_out(64);
 clear_to_color(tela,255);
 draw_sprite(tela,data[ZZLOGO].dat,1,1);
 text_mode(-1);
 textout(tela,data[ZFONT].dat,"INICIAR", (rx/2)-(text_length(data[ZFONT].dat,"INICIAR")/2),260,103);
 textout(tela,data[ZFONT].dat,"VER RECORDES", (rx/2)-(text_length(data[ZFONT].dat,"VER RECORDES")/2),280,103);
 textout(tela,data[ZFONT].dat,"CREDITOS", (rx/2)-(text_length(data[ZFONT].dat,"CREDITOS")/2),300,103);
 textout(tela,data[ZFONT].dat,"INSTRUCOES", (rx/2)-(text_length(data[ZFONT].dat,"INSTRUCOES")/2),320,103);
 textout(tela,data[ZFONT].dat,"SAIR", (rx/2)-(text_length(data[ZFONT].dat,"SAIR")/2),340,103);
 textout(tela,data[ZFONT].dat,"Copyright (c) 2001 David Gustavo Maziero / DGM",
  (rx/2)-(text_length(data[ZFONT].dat,"Copyright (c) 2001 David Gustavo Maziero / DGM")/2),460,103);
 blit(tela,screen,0,0,0,0,rx,ry);
 fade_in(data[PALETA].dat,1);
 rest(50);

 if(asom==1) { if(somativo==0) { play_midi(data[ZMNOVI].dat, FALSE); somativo=1; } }

 a=1;    op=1;    y=240;  x=240;  bo=0;   xx=5;
 while(a==1){
  bo++;
  if(bo==10) {bo=0;}
  if(bo<5) {xx--;}
  if(bo>=5) {xx++;}

  rectfill( tela, 100,240,550,400,255 );
  textout(tela,data[ZFONT].dat,"(((", 5+x-xx,y+(op*20),87);
  textout(tela,data[ZFONT].dat,")))", x+xx+140,y+(op*20),87);

  if(op==1) { sombral("INICIAR", (rx/2)-(text_length(data[ZFONT].dat,"INICIAR")/2),260); }
  else { textout(tela,data[ZFONT].dat,"INICIAR", (rx/2)-(text_length(data[ZFONT].dat,"INICIAR")/2),260,103); }
  if(op==2) { sombral("VER RECORDES", (rx/2)-(text_length(data[ZFONT].dat,"VER RECORDES")/2),280); }
  else { textout(tela,data[ZFONT].dat,"VER RECORDES", (rx/2)-(text_length(data[ZFONT].dat,"VER RECORDES")/2),280,103); }
  if(op==3) { sombral("CREDITOS", (rx/2)-(text_length(data[ZFONT].dat,"CREDITOS")/2),300); }
  else { textout(tela,data[ZFONT].dat,"CREDITOS", (rx/2)-(text_length(data[ZFONT].dat,"CREDITOS")/2),300,103); }
  if(op==4) { sombral("INSTRUCOES", (rx/2)-(text_length(data[ZFONT].dat,"INSTRUCOES")/2),320); }
  else { textout(tela,data[ZFONT].dat,"INSTRUCOES", (rx/2)-(text_length(data[ZFONT].dat,"INSTRUCOES")/2),320,103); }
  if(op==5) { sombral("SAIR", (rx/2)-(text_length(data[ZFONT].dat,"SAIR")/2),340); }
  else { textout(tela,data[ZFONT].dat,"SAIR", (rx/2)-(text_length(data[ZFONT].dat,"SAIR")/2),340,103); }

  vsync();
  blit(tela,screen,0,0,0,0,rx,ry);

  if(keypressed()) { pkey=readkey(); } else { pkey=0; }
  if( ((pkey>>8)==KEY_DOWN) && op<5 ) { op++;}
  if( ((pkey>>8)==KEY_UP) && op>1 )   { op--;}
  if(key[KEY_ENTER]){a=2;}
 }
 if(op==3) { creditos(); goto inicio; }
 if(op==4) { instru(); goto inicio; }
 if(op==2) { goto inicio; }

 stop_midi();
 if(op==1) { playgame(); }
 if(op==5) { endmsg(); }
}

//**
void apresenta()
{
 int k2;

 blit(tela,tela2,0,0,0,0,rx,ry);
 sombralc("** VAI!!! **",230,2 );
 k2=0;
 while(k2<6) {
  blit(tela2,screen,180,200,180,200,200,50);
  rest(250);
  blit(tela,screen,180,200,180,200,200,50);
  rest(250);
  k2++;
 }
}

//***
void poecursor( int px, int pxx )
{
 line(tela,230,230,410,230,103);
 line(tela,230,250,410,250,103);
 circle(tela,259+(px*20)+pxx,240,8,87);
 circle(tela,259+(px*20)+pxx,240,9,87);
}

//**** VERIFICAPECA
void verificapeca() {
int x,y; //,ini,ey;
//int back;

for(y=0;y<7;y++){
 for(x=0;x<7;x++){
  if((pa[x][y]>-1) && (pa[x][y+1]<=-1)) {
    pa2[x][y]+=2; pa[x][y+1]=-2;
    if(pa2[x][y]>=20) {
     pa[x][y+1]=pa[x][y];
     pa[x][y]=-1;
     pa2[x][y]=0;
     pa2[x][y+1]=0;
    }
  } //if
 } } 

for(y=14;y>7;y--){
 for(x=0;x<7;x++){
  if((pa[x][y]>-1) && (pa[x][y-1]==-1)) {
    pa2[x][y]-=2; // pa[x][y-1]=-2;
    if(pa2[x][y]<=-20) {
     pa[x][y-1]=pa[x][y];
     pa[x][y]=-1;
     pa2[x][y]=0;
     pa2[x][y-1]=0;
    }
  } //if
 } } 

}

//**
void gameover()
{
 int y; //,r;
 for(y=0;y<481;y+=2) {
  clear(tela2);
  blit(tela,tela2,0,0,0,y,640,480-y);
  vsync();
  blit(tela2,screen,0,0,0,0,640,480);
 }
 clear(screen);
 clear_keybuf();
// readkey();
}



//****************************************************************************
int playgame() {

 int x,y,dx;
 int px,pxx,jogo;
 int movx;
 int dyy[7];
 int pontos,bolas,nivel;
 int back2,back,tmp,ss,ss2,pode,bolini;

 int ddx,col,sen,ddxx,cor;
 ddx=0; ddxx=0;
 col=0; cor=0;
 sen=0;
 pode=0;

 bolini=0;
 back=0;
 ss=0; ss2=0;
 pontos=0; bolas=0; nivel=1;
 px=3; pxx=0; movx=0;
 jogo=1;
 dx=0;
 for(x=0;x<7;x++) dyy[x]=0;

 for(y=0;y<15;y++)
 for(x=0;x<7;x++) { pa[x][y]=-1;  pa2[x][y]=0; }

 for(y=6;y<9;y++)
 for(x=0;x<7;x++) pa[x][y]=rand()%8;
 
 fade_out(64);
 clear_to_color(tela,52);
 for(y=0;y<8;y++)
  for(x=0;x<8;x++) draw_sprite(tela,data[8].dat, 40+(x*20), 70+(y*20) );
  textout(tela,data[ZFONT].dat,"SphereS", 95,80,103);
  textout(tela,data[ZFONT].dat,"DGM", 105,210,103);
 for(y=0;y<17;y++)
 for(x=0;x<9;x++) draw_sprite(tela,data[8].dat, 230+(x*20), 70+(y*20) );
 blit(tela,tela2,0,0,0,0,rx,ry);

  textout(tela,data[ZFONT].dat,"Pontos : 0", 60,115,103);
  textout(tela,data[ZFONT].dat,"Bolas  : 0", 60,140,103);
  textout(tela,data[ZFONT].dat,"Nivel   : 1", 60,165,103);
                              
 for(y=0;y<15;y++)
 for(x=0;x<7;x++) {
  if(pa[x][y]>-1) { draw_sprite(tela,data[ pa[x][y] ].dat, 250+(x*20), 90+(y*20) ); }
 }

 poecursor(px,pxx);

 blit(tela,screen,0,0,0,0,rx,ry);
 blit(tela2,tela3,0,0,0,0,rx,ry);
 fade_in(data[PALETA].dat,1);

 apresenta();
 blit(tela3,tela2,0,0,0,0,rx,ry);

 if(asom==1) { play_midi(data[ ( rand() % 1 )+12 ].dat, TRUE ); }

 tmp=0;

//**** Loop do jogo
 while(jogo==1){
  tmp++;
  if(tmp>1000) { tmp=0; }
  if( (bolas-bolini)>=30 ) {
   bolini=bolas;
   nivel++;
  }

  if(ss==1) {
   if(ss2==0) { play_sample(data[ZSBIP].dat, 200, 127, 1000, FALSE); }
   if(ss2==5) { play_sample(data[ZSBIP].dat, 200, 127, 1000, FALSE); }
   if(ss2==10) { play_sample(data[ZSBIP].dat, 200, 127, 1000, FALSE); }
   if(ss2==15) { play_sample(data[ZSBIP].dat, 200, 127, 1000, FALSE); }
   if(ss2==20) { play_sample(data[ZSBIP].dat, 200, 127, 1000, FALSE); }
   if(ss2==25) { play_sample(data[ZSBIP].dat, 200, 127, 1000, FALSE); }
   if(ss2>=30) { play_sample(data[ZSBIP].dat, 200, 127, 1000, FALSE); ss=0; ss2=0; }
   ss2++;
  }
  if(ss==2) {
   if(ss2==0) { play_sample(data[ZSBIP].dat, 200, 127, 1000, FALSE); }
   if(ss2==5) { play_sample(data[ZSBIP].dat, 200, 127, 1000, FALSE); }
   if(ss2==10) { play_sample(data[ZSBIP].dat, 200, 127, 1000, FALSE); }
   if(ss2==15) { play_sample(data[ZSBIP].dat, 200, 127, 1000, FALSE); }
   if(ss2==20) { play_sample(data[ZSBIP].dat, 200, 127, 1000, FALSE); }
   if(ss2>=25) { play_sample(data[ZSBIP].dat, 200, 127, 1000, FALSE); ss=0; ss2=0; }
   ss2++;
  }
  if(ss==3) {
   if(ss2==0) { play_sample(data[ZSBIP].dat, 200, 127, 1000, FALSE); }
   if(ss2==5) { play_sample(data[ZSBIP].dat, 200, 127, 1000, FALSE); }
   if(ss2==10) { play_sample(data[ZSBIP].dat, 200, 127, 1000, FALSE); }
   if(ss2==15) { play_sample(data[ZSBIP].dat, 200, 127, 1000, FALSE); }
   if(ss2>=20) { play_sample(data[ZSBIP].dat, 200, 127, 1000, FALSE); ss=0; ss2=0; }
   ss2++;
  }
  if(ss==4) {
   if(ss2==0) { play_sample(data[ZSBIP].dat, 200, 127, 1000, FALSE); }
   if(ss2==5) { play_sample(data[ZSBIP].dat, 200, 127, 1000, FALSE); }
   if(ss2==10) { play_sample(data[ZSBIP].dat, 200, 127, 1000, FALSE); }
   if(ss2>=15) { play_sample(data[ZSBIP].dat, 200, 127, 1000, FALSE); ss=0; ss2=0; }
   ss2++;
  }

   if(tmp==200-(nivel*10)){
   tmp=0;
zcomeco:;
   x=rand()%7;
   if((rand()%2)==0)
    { if(pa[x][0]==-1) { pa[x][0]=rand()%8;} else goto zcomeco; }
    else
    { if(pa[x][14]==-1) { pa[x][14]=rand()%8;} else goto zcomeco; }
  }

  blit(tela2,tela,250,90,250,90,140,300);

  //verifica��es

  verificapeca();

  //verifica a ocorrencia dos pontos
  // 7 bolas
  if(pa[0][7]==pa[1][7] && pa[1][7]==pa[2][7] && pa[2][7]==pa[3][7] &&
     pa[3][7]==pa[4][7] && pa[4][7]==pa[5][7] && pa[5][7]==pa[6][7] && pa[1][7]>-1 ) {
    for(x=0;x<7;x++) { pa[x][7]=-1; pa2[x][7]=0; }
    pontos+=100;
    bolas+=7; ss=1; ss2=0;
  }
  // 6 bolas
  for(x=0;x<2;x++) {
   if(pa[x][7]==pa[x+1][7] && pa[x+1][7]==pa[x+2][7] && pa[x+2][7]==pa[x+3][7] &&
      pa[x+3][7]==pa[x+4][7] && pa[x+4][7]==pa[x+5][7] && pa[x][7]>-1 ) {
     for(y=0;y<6;y++) { pa[x+y][7]=-1; pa2[x+y][7]=0; }
     pontos+=25;
     bolas+=6; ss=2; ss2=0;
   }
  }
  // 5 bolas
  for(x=0;x<3;x++) {
   if(pa[x][7]==pa[x+1][7] && pa[x+1][7]==pa[x+2][7] && pa[x+2][7]==pa[x+3][7] &&
      pa[x+3][7]==pa[x+4][7] && pa[x][7]>-1 ) {
     for(y=0;y<5;y++) { pa[x+y][7]=-1; pa2[x+y][7]=0; }
     pontos+=15;
     bolas+=5; ss=3; ss2=0;
   }
  }
  // 4 bolas
  for(x=0;x<4;x++) {
   if(pa[x][7]==pa[x+1][7] && pa[x+1][7]==pa[x+2][7] && pa[x+2][7]==pa[x+3][7] &&
      pa[x][7]>-1 ) {
     for(y=0;y<4;y++) { pa[x+y][7]=-1; pa2[x+y][7]=0; }
     pontos+=10;
     bolas+=4; ss=4; ss2=0;
   }
  }




  //coloca as bolas na tela
  for(y=0;y<7;y++)
  for(x=0;x<7;x++)
   if(pa[x][y]>-1) {
    if(pa2[x][y]==0) { draw_sprite(tela,data[ pa[x][y] ].dat, 250+(x*20), 90+(y*20) + dyy[x] ); }
    if(pa2[x][y]!=0) { draw_sprite(tela,data[ pa[x][y] ].dat, 250+(x*20), 90+(y*20) + pa2[x][y] ); }
   }
  for(y=8;y<15;y++)
  for(x=0;x<7;x++)
   if(pa[x][y]>-1) {
    if(pa2[x][y]==0) { draw_sprite(tela,data[ pa[x][y] ].dat, 250+(x*20), 90+(y*20) + dyy[x] ); }
    if(pa2[x][y]!=0) { draw_sprite(tela,data[ pa[x][y] ].dat, 250+(x*20), 90+(y*20) + pa2[x][y] ); }
   }
  y=7;
  for(x=0;x<7;x++) {
   if(pa[x][y]>-1) { draw_sprite(tela,data[ pa[x][y] ].dat, 250+(x*20) + dx, 90+(y*20) + dyy[x] ); }
  }

  if(pa[6][7]>-1) { draw_sprite(tela,data[ pa[6][7] ].dat, 230 + dx, 90+(7*20) + dyy[6] ); }
//  if(pa[0][7]>-1) { draw_sprite(tela,data[ pa[0][7] ].dat, 230+160 + dx, 90+(7*20) + dyy[0] ); }

//  if(sen!=0) { draw_sprite(tela,data[ cor ].dat, 250+ (col*20), 90+(ddxx*20) + ddx ); }

  poecursor(px,pxx);

  //coloca o placar
  blit(tela2,tela,60,115,60,115,120,65);
  textprintf(tela,data[ZFONT].dat,60,115,103,"Pontos : %d", pontos);
  textprintf(tela,data[ZFONT].dat,60,140,103,"Bolas  : %d", bolas);
  textprintf(tela,data[ZFONT].dat,60,165,103,"Nivel   : %d", nivel);

  vsync();
  blit(tela,screen,250,90,250,90,140,300);
  blit(tela,screen,60,115,60,115,120,65);

  //ve se deu game-over
  pode=1;
  for(y=0;y<14;y++){
  for(x=0;x<7;x++){
   if(pa[x][y]<0) {pode=0;}
  }}
  if(pode==1) { gameover(); }

  //verifica as teclas

  if(key[KEY_RIGHT] && px<6 && movx==0) { movx=1;
   if(asom==1) { play_sample(data[ZSBIP2].dat, 200, 127, 1250, FALSE); }
  }
  if(key[KEY_LEFT] && px>0 && movx==0) { movx=2;
   if(asom==1) { play_sample(data[ZSBIP2].dat, 200, 127, 1250, FALSE); }
  }

  pode=0;
  for(y=0;y<15;y++) pode=pode+pa2[px][y];

  if(key[KEY_UP] && movx==0 && pa[px][8]!=-1 && pode==0 &&
     pa[px][0]==-1 && pa2[px][0]==0 && pa[px][7]!=-1) { movx=3;
   if(asom==1) { play_sample(data[ZSBIP2].dat, 255, 127, 1000, FALSE); }
  }
  if(key[KEY_DOWN] && movx==0 && pa[px][6]!=-1 && pode==0 &&
     pa[px][14]==-1 && pa2[px][14]==0 && pa[px][7]!=-1 ) { movx=4;
   if(asom==1) { play_sample(data[ZSBIP2].dat, 255, 127, 1000, FALSE); }
  }

  if(key[KEY_SPACE] && movx==0) { movx=5;
   if(asom==1){ play_sample(data[ZSBIP2].dat, 255, 127, 500, FALSE); }
  }

  if(key[KEY_ESC]) { jogo=0; }
  if(key[KEY_F12]) { nivel=19; }

  //verifica os movimentos
  if(movx==1) { //cursor para direita
   pxx++;
   if(pxx>=20) {
    pxx=0; px++; movx=0; dx=0;
   } }
  if(movx==2) { //cursor para esquerda
   pxx--;
   if(pxx<=-20) {
    pxx=0; px--; movx=0; dx=0;
  } }
  if(movx==3) { //coluna pra cima
   dyy[px]--;
   if(dyy[px]<=-20) {
    dyy[px]=0; movx=0;
    back=pa[px][0];
    back2=pa2[px][0];
    for(y=0;y<14;y++) { pa[px][y]=pa[px][y+1]; pa2[px][y]=pa2[px][y+1]; }
    pa[px][14]=back;
    pa2[px][14]=back2;
   }  }
  if(movx==4) { //coluna pra baixo
   dyy[px]++;
   if(dyy[px]>=20) {
    dyy[px]=0; movx=0;
    back=pa[px][14];
    back2=pa2[px][14];
    for(y=14;y>0;y--) { pa[px][y]=pa[px][y-1]; pa2[px][y]=pa2[px][y-1]; }
    pa[px][0]=back;
    pa2[px][0]=back2;
   }  }
  if(movx==5) { //linha do meio deslocando-se pra direita
   dx++;
   if(dx>=20) {
    dx=0; movx=0;
    back=pa[6][7];
    for(x=6;x>0;x--) pa[x][7]=pa[x-1][7];
    pa[0][7]=back;
   } }

 }
 
 gameover();
 creditos();
// clear_keybuf();
// readkey();

 return 0;
}



//****************************************************************************
int main()
{
  //**** inicializando o ALLEGRO ****
  rx=640; ry=480; col=8;
  allegro_init();            install_keyboard();
  install_timer();           set_color_depth(col);
  if( set_gfx_mode(GFX_AUTODETECT,rx,ry,0,0) !=0){
    allegro_exit();   return 0;
  }

  //variavel para com ou sem som
  asom = 1;   // 0-sem som  1-com som

 if(asom==1){
  if (install_sound(DIGI_AUTODETECT, MIDI_AUTODETECT, "" ) != 0) {
    printf("\nErro ao inicializar placa de som. \n%s\n\n", allegro_error);
    exit(1);
  } }

  data = load_datafile("data.dat");

  tela=create_bitmap_ex(col,rx,ry);
  tela2=create_bitmap_ex(col,rx,ry);
  tela3=create_bitmap_ex(col,rx,ry);

  //srandom(time(0));

  rest(250);
  DGMLOGO();

  poenome();

  unload_datafile(data);
  remove_timer();
  allegro_exit();

 return 0;
} // fim!

END_OF_MAIN();