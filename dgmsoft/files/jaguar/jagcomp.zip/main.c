/*
	JGASM - Jaguar Virtual Video-Game Assembler
	version 0.1

	by David G. Maziero
	http://dgm.prophp.org/jaguar/

	This is a _very_ simple assembler to the JG82 microprocessor.

	Aspects of this assembler:
		label: -> This is a label
		255    -> Notation for decimal numbers
		$FF    -> Notation for hexadecimal numbers
		#1010  -> Notation for binary numbers

	Rev 0.1 07/06/2006 -- Begin of work.
*/


#include "global.h"
#include "preproc.h"
#include "token.h"
#include "assemble.h"


/* PrintLogo - Print the credit message */
void PrintLogo()
{
	printf( "Jaguar Virtual Video-Game Assembler v%d.%d.\n", version_major, version_minor );
	printf( "Developed by David G. Maziero\n\n" );
}


/* PrintHelp - Print the command-line options */
void PrintHelp()
{
	printf( "    How to use:\n" );
	printf( "        jgasm source.jga [-o binary.bin] [-options]\n\n" );
	printf( "    Options are:\n" );
	printf( "        -o  : Specify the output file\n" );
	printf( "        -nl : Display no logo\n" );
	printf( "        -nv : Not in Verbose mode\n" );
	printf( "\n" );
}


/* ParseArgs - Parse all the command-line options */
int ParseArgs( int argc, char **argv )
{
	int l;
	for( l=1; l<argc; l++ )
	{
		/* options */
		if( argv[l][0]=='-' )
		{
			if( argv[l][1]=='n')
			{
				/* no logo */
				if( argv[l][2]=='l')
				{
					display_logo = 0;
				} else
				/* no verbose */
				if( argv[l][2]=='v')
				{
					verbose_mode = 0;
				}
			} else 
			if( argv[l][1]=='o')
			{
				/* output file */
				++l;
				if( l>=argc ) break;
				if( output_file!=NULL ) free( output_file );
				output_file = (char*)malloc( strlen(argv[l])+1 );
				strcpy( output_file, argv[l] );
				output_file_set = 1;
				continue;
			}
		} else {
			/* input file, I suppose */
			if( input_file!=NULL ) free( input_file );
			input_file = (char*)malloc( strlen(argv[l])+1 );
			strcpy( input_file, argv[l] );
			input_file_set = 1;
		}
	}

	if( display_logo ) PrintLogo();

	/* no input file? */
	if( input_file_set==0 )
	{
		PrintLogo();
		PrintHelp();
		printf( "    No input file specified.\n\n" );
		return ERROR;
	} else {
		/* verify if the file exists */
		FILE *f = fopen( input_file, "r" );
		if( f==NULL ) 
		{
			printf( "    Input file \"%s\" not found.\n\n", input_file );
			return ERROR;
		}
		fclose( f );
	}

	/* no output file? */
	if( output_file_set==0 )
	{
		int l, s = strlen( input_file );
		for( l=0; l<s; ++l )
		{
			if( input_file[l]=='.' ) {
				input_file[l]='\0';
				break;
			}
		}
		output_file = (char*)malloc( l+5 );
		strcpy( output_file, input_file );
		strcat( output_file, ".bin" );
		printf("out: [%s]\n", output_file);		
		input_file[l]='.';
	}

	return TRUE;
}


/* Main function */
int main( int argc, char *argv[] )
{
	int return_value;
	int saved_bytes = 0;
	struct SLine *tmp;

	/* parse the command-line options */
	if( ParseArgs( argc, argv )==ERROR ) return ERROR;

	/* begin the measurement of the processing time */
	t_start = clock();

	head_line = (struct SLine*)malloc( sizeof(struct SLine) );
	current_line = head_line;

	/* do the preprocessing */
	if( !PreProcessor() )
	{
		return_value = ERROR;
		goto main_end;
	}

	/* assemble the file */
	saved_bytes = Assemble();
	if( saved_bytes==ERROR ) 
	{
		saved_bytes = 0;
		return_value = ERROR;
	}

main_end:

	/* finish the measurement of the processing time */
	t_end = clock();

	/* print the stats */
	if( verbose_mode )
	{
		if( error_count>0 )
		{
			printf( "\nFailed, %d errors.\n", error_count );
		} else {
			printf( "\nSuccess.\n" );
			printf( " %d symbol(s) found.\n", symbol_count );
		}
		printf( " %d lines of code.\n", lines_count );
		printf( " %d bytes saved.\n", saved_bytes );
		/* printf(" %3.3fs total processing time.\n\n", (float)(t_end-t_start)/(float)(CLOCKS_PER_SEC) ); */
		printf( " %d.%03ds total processing time.\n\n", (int)((t_end-t_start)/CLK_TCK), (int)((t_end-t_start)%CLK_TCK) );

	}

	/* free memory */
	if( input_file ) free( input_file );
	if( output_file ) free( output_file );

	/* free symbol and file table */
	if( symbol_count>0 )
	{
		uint l;
		for( l=0; l<symbol_count; l++ )
		{
			printf( "Symbol: [%s], Value: [$%06X]\n", symbol_list[l].name, symbol_list[l].value );
			free( symbol_list[l].name );
		}
	}
	if( file_count>0 )
	{
		uint l;
		for( l=0; l<file_count; l++ )
		{
			/*printf( "File: [%s]\n", file_list[l].name );*/
			free( file_list[l].name );
		}
	}

	FirstLine();
	do
	{
		if( tmp ) free( tmp );
		if( current_line->line )
		{
			/*printf( "Lines: [%s]\n", current_line->line );*/
			free( current_line->line );
		}
		tmp = current_line;
	} while( NextLine() );
	free( tmp );

	return return_value;
}
