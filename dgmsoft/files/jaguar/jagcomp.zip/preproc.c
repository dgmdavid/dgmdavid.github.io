/*
	JGASM - Jaguar Virtual Video-Game Assembler
	version 0.1

	by David G. Maziero
	http://dgm.prophp.org/jaguar/
*/

#include "preproc.h"
#include "opcodes.h"


/* PreProcessor */
int PreProcessor()
{
	FILE *in_file;
	uint line_number = 0;

	if( verbose_mode ) 
	{
		printf( "Preprocessing file:" );
	}

	/* Jaguar ROM begins at $040000 */
	program_pointer = START_ADDRESS;

	AddFile( input_file );

	in_file = fopen( input_file, "rt" );
	while( !feof( in_file ) )
	{
		if( PreReadLine1Pass( in_file, 0, &line_number ) )
		{
			AddLine( 0, line_number, cur_line );
		}
	}
	fclose( in_file );

	if( error_count==0 )
	{
		if( verbose_mode ) printf( " Done.\n");
		return TRUE;
	} 

	return FALSE;
}


/* IncludeFile */
int IncludeFile( char *name )
{
	FILE *include_file;
	int tmp, inc_file, inc_line = 0;
	uint b_err_count;

	/* validate file name */
	tmp = ValidateIncludeName( name );
	if( tmp==ERROR ) return SetError( Err_Msg[ERR_INVALID_FILE_NAME] );

	/* include the file name on the file list */
	inc_file = AddFile( name );
	if( inc_file==ERROR ) return ERROR;

	include_file = fopen( name, "rt" );
	if( include_file==NULL ) return SetError( Err_Msg[ERR_FILE_NOT_FOUND] );

	printf("\n  Including file \"%s\":", name );
	b_err_count = error_count;

	while( !feof( include_file ) )
	{
		if( PreReadLine1Pass( include_file, (byte)inc_file, &inc_line ) )
		{
			AddLine( (byte)inc_file, inc_line, cur_line );
		}
	}
	fclose( include_file );
	if( error_count==b_err_count ) printf(" Ok.");

	return TRUE;
}


/* PreReadLine1Pass 
	First pass of the preprocessor:
		* read a line from file and cut useless parts of it
		* enumerate all symbols
		* verify opcodes and parameters of opcodes
		* include files (not binary)
*/
int PreReadLine1Pass( FILE *cur_file, byte file, uint *local_lines_count )
{
	int size, opcode, m_opcode, value;
	int tmp = FALSE;
	
	/* read the line from file */
	if( fgets( tmp_line, MAX_LINE_SIZE, cur_file )==NULL ) return FALSE;

	/* increment the local line counter */
	*local_lines_count+=1;

	/* cut comments and useless spaces */
	tmp = FixLine( tmp_line );
	if( tmp!=TRUE ) return FALSE;

	/* ok, parse the tokens */
	tmp = ParseToken( cur_line );
	if( tmp==ERROR ) goto readline_end;

	/**********************************************************************/
	/* is that a symbol? */
	/**********************************************************************/
	if( token.symbol[0]!='\0' )
	{
		/* check if it is already defined */
		if( symbol_count>0 )
		{
			if( FindSymbol( token.symbol )!=ERROR )
			{
				tmp = SetError( Err_Msg[ERR_SYMBOL_REDEFINED] );
				goto readline_end;
			}
		}
		/* symbol */
		if( token.type==SYMBOL )
		{
			/* parse the value */
			value = ParseArgAsValue( token.argument, FALSE );
			if( value==ERROR )
			{
				tmp = SetError( Err_Msg[ERR_INVALID_VALUE] );
				goto readline_end;
			}
			/* add it to the symbol list */
			tmp = AddSymbol( token.symbol, value );
			if( tmp==ERROR ) goto readline_end;
			/* do not add this line */
			tmp = FALSE;
			goto readline_end;
		} else
		/* label */
		if( token.type==LABEL )
		{
			/* add it to the symbol list */
			tmp = AddSymbol( token.symbol, program_pointer );
			if( tmp==ERROR ) goto readline_end;
			/* do not add, if no mnemonic */
			tmp = FALSE;
		}
	}

	/**********************************************************************/
	/* it contains a mnemonic? */
	/**********************************************************************/
	if( token.mnemonic[0]!='\0' )
	{
		/* find opcode size */
		tmp = MatchOpcode( FALSE, &size, &opcode, &m_opcode, &value );
		if( tmp==ERROR ) goto readline_end;

		/* catch special cases */

		/* operator expect string value? should be "include" */
		if( tmp==ST )
		{
			tmp = IncludeFile( token.argument );
			if( tmp==ERROR ) goto readline_end;
			/* don't add this line */
			tmp = FALSE;
			goto readline_end;
		}

		/* it expects a bin data? incbin */
		if( tmp==BIN )
		{
			FILE *bin_tmp;
			/* validate file name */
			if( !ValidateIncludeName( token.argument ) )
			{
				tmp = SetError( Err_Msg[ERR_INVALID_FILE_NAME] );
				goto readline_end;
			}
			bin_tmp = fopen( token.argument, "r" );
			/* not found? */
			if( bin_tmp==NULL )
			{
				tmp = SetError( Err_Msg[ERR_FILE_NOT_FOUND] );
				goto readline_end;
			}
			/* get its size */
			fseek( bin_tmp, 0, SEEK_END );
			/* increment program ponter */
			program_pointer += ftell( bin_tmp );
			fclose( bin_tmp );
			/* add this line */
			tmp = TRUE;
			goto readline_end;
		}

		/* it expects a data value? it must be "db" */
		if( tmp==DT )
		{
			/* TODO: validate and calculate data size */
			tmp = TRUE;
			goto readline_end;
		}

		/* increment program pointer by opcode size */
		program_pointer += size;
		/* add this line */
		tmp = TRUE;
	}
				
readline_end:

	/* good, no errors, so rebuild the cur_line */
	if( tmp==TRUE ) 
	{
		if( token.mnemonic[0]!='\0' )
		{
			if( token.argument[0]=='\0' )
			{
				sprintf( cur_line, "%s", token.mnemonic );
			} else {
				if( value<=0 )
				{
					sprintf( cur_line, "%s %s", token.mnemonic, token.argument );
				} else {
					sprintf( cur_line, "%s %d", token.mnemonic, value );
				}
			}
		}
	}

	/* show the error, if any */
	if( tmp==ERROR ) 
	{
		ShowError( file, *local_lines_count );
		error_count++;
		return FALSE;
	}

	return tmp;
}

