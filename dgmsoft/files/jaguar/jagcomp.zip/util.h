/*
	JGASM - Jaguar Virtual Video-Game Assembler
	version 0.1

	by David G. Maziero
	http://dgm.prophp.org/jaguar/
*/

#include "global.h"
#include "opcodes.h"

int FixLine( char *tmp_line );
int FindOperand( const char *mnemonic );
int MatchOpcode( byte check_symbols, int *size, int *opcode, int *m_opcode, int *value );
int MatchParam( int opcode, word arg );

int AddSymbol( const char *symbol, int value );
int FindSymbol( const char *symbol );

int AddFile( const char *name );
int IsAlpha( const char c );
int IsDigit( const char c );
int IsHex( const char c );
int IsBin( const char c );
int HexToWord( const char *hex );
int BinToWord( const char *binary );
int ParseArgAsValue( const char *param, byte check_symbols );
int ValidateIncludeName( char *param );
void StringToLower( char *string );
