/*
	JGASM - Jaguar Virtual Video-Game Assembler
	version 0.1

	by David G. Maziero
	http://dgm.prophp.org/jaguar/
*/

#include "global.h"

/* Error messages */
const char *Err_Msg[TOTAL_ERRORS] =
{	
	/* ERR_FILE_NOT_FOUND        0 */ "File not found.",
	/* ERR_LINE_TOO_LONG         1 */ "Line too long.",
	/* ERR_UNEXPECTED_ERROR      2 */ "Unexpected error code #%03d.",
	/* ERR_UNCLOSED_QUOTES       3 */ "Unclosed quotes.",
	/* ERR_EXCESSIVE_ARGS        4 */ "Excessive arguments.",

	/* ERR_INVALID_VALUE         5 */ "Invalid value.",
	/* ERR_INVALID_FILE_NAME     6 */ "Invalid file name.",
	/* ERR_INVALID_DEC_VALUE     7 */ "Invalid decimal value.",
	/* ERR_INVALID_HEX_VALUE     8 */ "Invalid hexadecimal value.",
	/* ERR_INVALID_BIN_VALUE     9 */ "Invalid binary value.",
	/* ERR_INVALID_JUMP_RANGE   10 */ "Invalid jump range.",

	/* ERR_OPERAND_NO_ARG       11 */ "Operand doesn't expect argument.",
	/* ERR_OPERAND_EXPECT_ARG   12 */ "Operand expects an argument.",
	/* ERR_OPERAND_BITTEST      13 */ "Operand expects a value between 0 and 7.",
	/* ERR_OPERAND_BITSHIFT     14 */ "Operand expects a value between 1 and 8.",	
	/* ERR_OPERAND_INVALID_ARG  15 */ "Invalid argument for operand.",
	/* ERR_OPERAND_UNDEFINED    16 */ "Undefined operand.",

	/* ERR_UNDEFINED_SYMBOL     17 */ "Undefined symbol.",
	/* ERR_SYMBOL_REDEFINED     18 */ "Symbol redefined.",
	/* ERR_EXPECTED_SYMBOL      19 */ "Expected symbol name, found a label.",
	/* ERR_INVALID_SYMBOL_NAME  20 */ "Invalid symbol name.",
	/* ERR_NO_LABEL_HERE        21 */ "Label declaration not allowed here.",

	/* ERR_MAX_SYMBOLS_REACHED  22 */ "You cannot define more than 8192 symbols.",
	/* ERR_MAX_INCLUDES_REACHED 23 */ "You cannot include more than 256 files.",
};

/* Global variables */
byte display_logo    = 1;
byte verbose_mode    = 1;
byte input_file_set  = 0;
byte output_file_set = 0;
uint lines_count     = 0;
uint error_count     = 0;
uint symbol_count    = 0;
uint file_count      = 0;
uint program_pointer = 0;
char *input_file     = NULL;
char *output_file    = NULL;
char cur_line[MAX_LINE_SIZE];
char tmp_line[MAX_LINE_SIZE];
clock_t t_start, t_end;
char last_error[256];
struct SSymbol_list symbol_list[MAX_SYMBOLS];
struct SFile_list file_list[MAX_FILES];
struct SLine *head_line;
struct SLine *current_line;
struct SToken token;


/* SetError */
int SetError( const char *error )
{
	strcpy( last_error, error );
	return ERROR;
}


/* ShowError */
void ShowError( byte file, uint line )
{
	printf( "\n  (%s) Error on line %d: %s", file_list[file], line, last_error );
}


/* AddLine */
void AddLine( byte file, uint line_number, const char *line )
{
	/* copy string to the current line */
	current_line->line = (char*)malloc( strlen(line)+1 );
	strcpy( current_line->line, line );
	
	current_line->file = file;
	current_line->line_number = line_number;

	/* alloc the next line */
	current_line->next = (struct SLine*)malloc( sizeof(struct SLine) );
	current_line = current_line->next;
	current_line->line = NULL;
	current_line->file = 0;
	current_line->line_number = 0;

	/* increment the global line counter */
	lines_count++;
}


/* FirstLine */
void FirstLine()
{
	current_line = head_line;
}


/* NextLine */
struct SLine *NextLine()
{
	return current_line = current_line->next;
}
