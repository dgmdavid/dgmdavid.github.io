/*
	JGASM - Jaguar Virtual Video-Game Assembler
	version 0.1

	by David G. Maziero
	http://dgm.prophp.org/jaguar/
*/

#include "global.h"
#include "opcodes.h"
#include "token.h"
#include "preproc.h"
#include "util.h" 


int Assemble();
