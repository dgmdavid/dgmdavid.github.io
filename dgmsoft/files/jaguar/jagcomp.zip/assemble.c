/*
	JGASM - Jaguar Virtual Video-Game Assembler
	version 0.1

	by David G. Maziero
	http://dgm.prophp.org/jaguar/
*/

#include "assemble.h"


/* Assemble
	This will generate the final binary file.
*/
int Assemble()
{
	FILE *out_file;
	int tmp = 0;
	int value = -1;
	int size;
	int saved_bytes;

	if( verbose_mode ) 
	{
		printf("Assembling file:");
	}

	out_file = fopen( output_file, "wb" );

	program_pointer = START_ADDRESS;
	FirstLine();
	do
	{
		if( (current_line->line==NULL) || (current_line->line[0]=='\0') ) continue;

		/* ok, parse the tokens */
		tmp = ParseToken( current_line->line );
		if( tmp==ERROR )
		{
			/* probably it __never__ will happen */
			SetError( "Unexpected error while assembling." );
			goto assemble_end;
		}

		/******************************************************************/
		/* it contains a mnemonic? */
		/******************************************************************/
		if( token.mnemonic!=NULL )
		{
			int oparg, opcode, opc;
		
			/* find operand size */
			oparg = MatchOpcode( TRUE, &size, &opcode, &opc, &value );
			if( oparg==ERROR ) 
			{
				tmp = ERROR;
				goto assemble_end;
			}

			/* increment the program pointer */
			program_pointer += size;

			/* no argument? */
			if( token.argument==NULL )
			{
				/* save opcode */
				fwrite( &Operand[opcode].opcodes[0].opcode, 1, 1, out_file );
				continue;
			}
			
			/* catch special cases */

			/* it expects a bin data? incbin */
			if( oparg==BIN )
			{
				FILE *bin_tmp;
				byte buffer[1024];
				size_t num_read;
				bin_tmp = fopen( token.argument, "r" );
				/* save its contents to out file */
				while( !feof(bin_tmp) )
				{
					num_read = fread( buffer, 1, 1024, bin_tmp );
					fwrite( buffer, 1, num_read, out_file );
				}
				program_pointer += ftell( bin_tmp );
				fclose( bin_tmp );
				continue;
			}

			/* it expects an address? */
			if( (oparg==A8) || (oparg==A16) || (oparg==A24) )
			{
				int distance;
				value = ParseArgAsValue( token.argument, TRUE );
				distance = value-program_pointer;
				printf("distance [%d][%d]\n",value,distance);
				/* check range for 8-bit address */
				if( oparg==A8 )
				{
					if( (distance<-128) || (distance>127) )
					{
						tmp = SetError( Err_Msg[ERR_INVALID_JUMP_RANGE]);
						goto assemble_end;
					}
					value = distance;
				}
				/* check range for 16-bit address */
				if( oparg==A16 )
				{
					if( (distance<-32768) || (distance>32767) )
					{
						tmp = SetError( Err_Msg[ERR_INVALID_JUMP_RANGE] );
						goto assemble_end;
					}
					value = distance;
				}
				/* check range for 24-bit address */
				if( oparg==A24 )
				{
					if( value>=16777216 ) 
					{
						tmp = SetError( Err_Msg[ERR_INVALID_JUMP_RANGE] );
						goto assemble_end;
					}
				}
			}

			/* it expects a data value? it must be "db" */
			if( oparg==DT )
			{
				/* TODO: parse the value and save */
				continue;
			}

			/* save opcode and its parameter */
			fwrite( &Operand[opcode].opcodes[opc].opcode, 1, 1, out_file );
			if( size==2 )
			{
				fwrite( &(byte)value, 1, 1, out_file );
			} else
			if( size==3 )
			{
				fwrite( &(word)value, 2, 1, out_file );
			} else
			if( size==4 )
			{
				fwrite( &(uint)value, 3, 1, out_file );
			}
		}
	
	} while( NextLine() );

assemble_end:

	/* get how much bytes were written */
	saved_bytes = ftell( out_file );

	fclose( out_file );

	if( tmp==ERROR )
	{
		ShowError( current_line->file, current_line->line_number );
		error_count++;
		return ERROR;
	}

	if( verbose_mode ) 
	{
		printf(" Done.\n");
	}

	return saved_bytes;
}
