/*
	JGASM - Jaguar Virtual Video-Game Assembler
	version 0.1

	by David G. Maziero
	http://dgm.prophp.org/jaguar/
*/

#include "global.h"

#ifndef __TOKEN__
#define __TOKEN__

#define SYMBOL	0
#define LABEL   1

int ParseToken( const char *line );

#endif
