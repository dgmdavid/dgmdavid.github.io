/*
	JGASM - Jaguar Virtual Video-Game Assembler
	version 0.1

	by David G. Maziero
	http://dgm.prophp.org/jaguar/
*/

#include "global.h"
#include "token.h"
#include "util.h"


int PreProcessor();
int PreReadLine1Pass( FILE *cur_file, byte file, uint *local_lines_count );
int IncludeFile( char *name );

