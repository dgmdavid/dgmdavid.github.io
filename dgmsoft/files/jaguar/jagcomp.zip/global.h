/*
	JGASM - Jaguar Virtual Video-Game Assembler
	version 0.1

	by David G. Maziero
	http://dgm.prophp.org/jaguar/
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

/* Basic types */
typedef unsigned char byte;
typedef unsigned short int word;
typedef unsigned int uint;

/* Constant and defines */
#define START_ADDRESS  0x040000
#define MAX_LINE_SIZE  1024
#define MAX_SYMBOLS    8192
#define MAX_FILES	   256
#define version_major  0
#define version_minor  1

#define FALSE     0
#define TRUE	  1
#define ERROR	 -1

#define Hex_Notation	'$'
#define Bin_Notation	'%'

/* Error messages */
#define ERR_FILE_NOT_FOUND        0 
#define ERR_LINE_TOO_LONG         1 
#define ERR_UNEXPECTED_ERROR      2 
#define ERR_UNCLOSED_QUOTES       3 
#define ERR_EXCESSIVE_ARGS        4 
#define ERR_INVALID_VALUE         5 
#define ERR_INVALID_FILE_NAME     6 
#define ERR_INVALID_DEC_VALUE     7 
#define ERR_INVALID_HEX_VALUE     8 
#define ERR_INVALID_BIN_VALUE     9 
#define ERR_INVALID_JUMP_RANGE   10 
#define ERR_OPERAND_NO_ARG       11 
#define ERR_OPERAND_EXPECT_ARG   12 
#define ERR_OPERAND_BITTEST      13 
#define ERR_OPERAND_BITSHIFT     14 	
#define ERR_OPERAND_INVALID_ARG  15 
#define ERR_OPERAND_UNDEFINED    16
#define ERR_UNDEFINED_SYMBOL     17 
#define ERR_SYMBOL_REDEFINED     18 
#define ERR_EXPECTED_SYMBOL      19 
#define ERR_INVALID_SYMBOL_NAME  20 
#define ERR_NO_LABEL_HERE        21 
#define ERR_MAX_SYMBOLS_REACHED  22 
#define ERR_MAX_INCLUDES_REACHED 23 

#define TOTAL_ERRORS  24

#ifndef __GLOBAL__
#define __GLOBAL__

/* list of symbols */
struct SSymbol_list
{
	char *name;
	uint value;
};

/* list of files */
struct SFile_list
{
	char *name;
};

/* list of lines */
struct SLine
{
	struct SLine *next;
	char *line;
	byte file;
	uint line_number;
};

/* token */
struct SToken
{
	byte type;
	char symbol[MAX_LINE_SIZE];
	char mnemonic[MAX_LINE_SIZE];
	char argument[MAX_LINE_SIZE];
};

int SetError( const char *error );
void ShowError( byte file, uint line );

void AddLine( byte file, uint line_number, const char *line );
void FirstLine();
struct SLine *NextLine();

#endif

/* Constants */
extern const char *Err_Msg[TOTAL_ERRORS];

/* Global variables */
extern byte display_logo;
extern byte verbose_mode;
extern byte input_file_set;
extern byte output_file_set;
extern uint lines_count;
extern char *input_file;
extern char *output_file;
extern char cur_line[MAX_LINE_SIZE];
extern char tmp_line[MAX_LINE_SIZE];
extern uint program_pointer;
extern clock_t t_start, t_end;
extern char last_error[256];
extern uint error_count;
extern struct SSymbol_list symbol_list[MAX_SYMBOLS];
extern uint symbol_count;
extern struct SFile_list file_list[MAX_FILES];
extern uint file_count;
extern struct SToken token;
extern struct SLine *head_line;
extern struct SLine *current_line;
