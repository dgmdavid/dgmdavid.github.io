/*
	JGASM - Jaguar Virtual Video-Game Assembler
	version 0.1

	by David G. Maziero
	http://dgm.prophp.org/jaguar/
*/

#include "token.h"
#include "opcodes.h"


/* ParseToken */
int ParseToken( const char *line )
{
	byte islabeled = 0;
	byte quotes = 0;
	byte count = 0;
	int  tmp = 0;
	int  r, r2;
	int  begin, end;
	int  len = strlen( line );
	char tmp_token[3][MAX_LINE_SIZE];

	token.type     = 0;
	token.symbol[0]   = '\0';
	token.mnemonic[0] = '\0';
	token.argument[0] = '\0';

	tmp_token[0][0]='\0';
	tmp_token[1][0]='\0';
	tmp_token[2][0]='\0';

	/* divide the line into words */
	for( r=0; r<len; r++ )
	{
		/* begin a word */
		if( line[r]!=' ' )
		{
			begin = r;
			/* find the end of the word */
			for( r2=r; r2<len; r2++ )	
			{
				if( line[r2]=='"' ) quotes=!quotes;
				if( quotes==0 )	if( line[r2]==' ' ) break;
			}
			end = r2;
			if( quotes!=0 ) return SetError( Err_Msg[ERR_UNCLOSED_QUOTES] );
			memcpy( tmp_token[count], line+begin, (end-begin) );
			tmp_token[count][(end-begin)]='\0';
			r=end-1;
			count++;
			if( count==3 ) break;
		}
	}
	
	/* did not reach the end of the line? */
	if( r<len-1 ) return SetError( Err_Msg[ERR_EXCESSIVE_ARGS] );

	/* no words found? */
	if( count==0 ) return FALSE;

	/* identify the tokens */
	
	/* symbol definition by "equ" or "=" */
	if( (strcmp( tmp_token[1], "equ" )==0) || (strcmp( tmp_token[1], "=" )==0) )
	{
		if( tmp_token[0][strlen(tmp_token[0])-1]==':' ) 
		{
			return SetError( Err_Msg[ERR_NO_LABEL_HERE] );
		}
		/* symbols must begin with a letter */
		if( (tmp_token[0][0]<'a') || (tmp_token[0][0]>'z') ) 
		{
			return SetError( Err_Msg[ERR_INVALID_SYMBOL_NAME] );
		}
		/* symbol values mustn't begin with a letter, nor it can be null */
		if( tmp_token[2][0]=='\0' || ((tmp_token[2][0]>='a') && (tmp_token[2][0]<='z')) )
		{
			return SetError( Err_Msg[ERR_INVALID_VALUE] );
		}
		/* copy the respectives values */
		token.type = SYMBOL;
		strcpy( token.symbol,   tmp_token[0] );
		strcpy( token.argument, tmp_token[2] );
		return TRUE;
	}
	
	/* search for label */
	for( r=0; r<count; ++r )
	{
		r2 = strlen( tmp_token[r] );
		/* label? */
		if( tmp_token[r][r2-1]==':' )
		{
			if( r==0 )
			{
				/* copy the label name */
				token.type = LABEL;
				strcpy( token.symbol, tmp_token[r] );
				token.symbol[r2-1]='\0';
				islabeled = 1;
			} else {
				return SetError( Err_Msg[ERR_NO_LABEL_HERE] );
			}
		}
	}

	/* mnemonic, if any */
	if( strlen( tmp_token[islabeled] )>0 )
	{
		if( islabeled==0 && count==3 )
		{
			return SetError( Err_Msg[ERR_EXCESSIVE_ARGS] );
		}
		
		/* copy mnemonic name */
		strcpy( token.mnemonic, tmp_token[islabeled] );
	
		/* copy argument, if any */
		if( strlen( tmp_token[islabeled+1] )>0 )
		{
			strcpy( token.argument, tmp_token[islabeled+1] );
			return islabeled+1;
		}

		return islabeled;
	}

	/* still here? */
	if( islabeled==0 ) return SetError( "Unexpected error code #002." );

	return TRUE;
}

