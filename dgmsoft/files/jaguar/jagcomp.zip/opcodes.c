/*
	JGASM - Jaguar Virtual Video-Game Assembler
	version 0.1

	by David G. Maziero
	http://dgm.prophp.org/jaguar/
*/

#include "opcodes.h"


struct SOperand Operand[NUM_OPERANDS] =
{ 
/* 
-mnemo.-  -allow.args-  -arg1 x opc-      -arg2 x opc-      -ag3 x opc- */
"nop",     NA,           0,OP_NOP,         0,0,              0,0,
	
"lda",     LA|I8,        LA,OP_LDA,        I8,OP_LDA_A8,     0,0,
"ldb",     LA|I8,        LA,OP_LDB,        I8,OP_LDB_A8,     0,0,
"ldc",     LA|I8,        LA,OP_LDC,        I8,OP_LDC_A8,     0,0,
	
"seta",    I8|RB|RC,     I8,OP_SETA_I8,    RB,OP_SETA_B,     RC,OP_SETA_C, 
"setb",    I8|RA|RC,     I8,OP_SETB_I8,    RA,OP_SETB_A,     RC,OP_SETB_C,
"setc",    I8|RA|RB,     I8,OP_SETC_I8,    RA,OP_SETC_A,     RB,OP_SETC_B,
	
"sets",    I24|I16|I8,   I24,OP_SETD_I24,  I16,OP_SETS_I16,  I8,OP_SETS_I8, 
"setd",    I24|I16|I8,   I24,OP_SETD_I24,  I16,OP_SETD_I16,  I8,OP_SETD_I8, 

"sta",     NA,           0,OP_STA,         0,0,              0,0,
"stb",     NA,           0,OP_STB,         0,0,              0,0,
"stc",     NA,           0,OP_STC,         0,0,              0,0,

"inca",    NA,           0,OP_INCA,        0,0,              0,0,
"incb",    NA,           0,OP_INCB,        0,0,              0,0,
"incc",    NA,           0,OP_INCC,        0,0,              0,0,
"incs",    NA,           0,OP_INCS,        0,0,              0,0,
"incd",    NA,           0,OP_INCD,        0,0,              0,0,
	
"deca",    NA,           0,OP_DECA,        0,0,              0,0,
"decb",    NA,           0,OP_DECB,        0,0,              0,0,
"decc",    NA,           0,OP_DECC,        0,0,              0,0,
"decs",    NA,           0,OP_DECS,        0,0,              0,0, 
"decd",    NA,           0,OP_DECD,        0,0,              0,0,

"adda",    I8 |RB|RC,    I8, OP_ADDA_I8,   RB,OP_ADDA_B,     RC,OP_ADDA_C, 
"addb",    I8 |RA|RC,    I8, OP_ADDB_I8,   RA,OP_ADDB_A,     RC,OP_ADDB_C,
"addc",    I8 |RA|RB,    I8, OP_ADDC_I8,   RA,OP_ADDC_A,     RB,OP_ADDC_B,
"adds",    I16|I8|RA,    I16,OP_ADDS_I16,  I8,OP_ADDS_I8,    RA,OP_ADDS_A, 
"addd",    I16|I8|RA,    I16,OP_ADDD_I16,  I8,OP_ADDD_I8,    RA,OP_ADDD_A,
	
"suba",    I8 |RB|RC,    I8, OP_SUBA_I8,   RB,OP_SUBA_B,     RC,OP_SUBA_C, 
"subb",    I8 |RA|RC,    I8, OP_SUBB_I8,   RA,OP_SUBB_A,     RC,OP_SUBB_C,
"subc",    I8 |RA|RB,    I8, OP_SUBC_I8,   RA,OP_SUBC_A,     RB,OP_SUBC_B,
"subs",    I16|I8|RA,    I16,OP_SUBS_I16,  I8,OP_SUBS_I8,    RA,OP_SUBS_A, 
"subd",    I16|I8|RA,    I16,OP_SUBD_I16,  I8,OP_SUBD_I8,    RA,OP_SUBD_A,

"tsta",    BS,           BS,OP_TSTA,       0,0,              0,0,
"tstb",    BS,           BS,OP_TSTB,       0,0,              0,0,
"tstc",    BS,           BS,OP_TSTC,       0,0,              0,0,

"anda",    I8|RB|RC,     I8,OP_ANDA_I8,    RB,OP_ANDA_B,     RC,OP_ANDA_C,
"andb",    I8|RA|RC,     I8,OP_ANDB_I8,    RA,OP_ANDB_A,     RC,OP_ANDB_C,
"andc",    I8|RA|RB,     I8,OP_ANDC_I8,    RA,OP_ANDC_A,     RB,OP_ANDC_B,

"ora",     I8|RB|RC,     I8,OP_ORA_I8,     RB,OP_ORA_B,      RC,OP_ORA_C,
"orb",     I8|RA|RC,     I8,OP_ORB_I8,     RA,OP_ORB_A,      RC,OP_ORB_C,
"orc",     I8|RA|RB,     I8,OP_ORC_I8,     RA,OP_ORC_A,      RB,OP_ORC_B,

"xora",    I8|RB|RC,     I8,OP_XORA_I8,    RB,OP_XORA_B,     RC,OP_XORA_C,
"xorb",    I8|RA|RC,     I8,OP_XORB_I8,    RA,OP_XORB_A,     RC,OP_XORB_C, 
"xorc",    I8|RA|RB,     I8,OP_XORC_I8,    RA,OP_XORC_A,     RB,OP_XORC_B,

"nota",    NA,           0,OP_NOTA,        0,0,              0,0,
"notb",    NA,           0,OP_NOTB,        0,0,              0,0,
"notc",    NA,           0,OP_NOTC,        0,0,              0,0,

"shla",    SF,           SF,OP_SHLA,       0,0,              0,0,
"shlb",    SF,           SF,OP_SHLB,       0,0,              0,0,
"shlc",    SF,           SF,OP_SHLC,       0,0,              0,0,

"shra",    SF,           SF,OP_SHRA,       0,0,              0,0,
"shrb",    SF,           SF,OP_SHRB,       0,0,              0,0,
"shrc",    SF,           SF,OP_SHRC,       0,0,              0,0,

"cmpa",    I8|RB|RC,     I8,OP_CMPA_I8,    RB,OP_CMPA_B,     RC,OP_CMPA_C,
"cmpb",    I8|RC,        I8,OP_CMPB_I8,    RC,OP_CMPB_C,     0, 0,  
"cmpc",    I8,           I8,OP_CMPC_I8,    0, 0,             0, 0,

"jmp",     A8,           A8, OP_JMP_A8,    0,0,              0,0,
"jmpf",    A16,          A16,OP_JMPF_A16,  0,0,              0,0,
"jmpa",    A24,          A24,OP_JMPA_A24,  0,0,              0,0,

"jz",      A8,           A8, OP_JZ_A8,     0,0,              0,0,
"jzf",     A16,          A16,OP_JZF_A16,   0,0,              0,0,
"jza",     A24,          A24,OP_JZA_A24,   0,0,              0,0,
"jnz",     A8,           A8, OP_JNZ_A8,    0,0,              0,0,
"jnzf",    A16,          A16,OP_JNZF_A16,  0,0,              0,0,
"jnza",    A24,          A24,OP_JNZA_A24,  0,0,              0,0,

"jc",      A8,           A8, OP_JC_A8,     0,0,              0,0,
"jcf",     A16,          A16,OP_JCF_A16,   0,0,              0,0,
"jca",     A24,          A24,OP_JCA_A24,   0,0,              0,0,
"jnc",     A8,           A8, OP_JNC_A8,    0,0,              0,0,
"jncf",    A16,          A16,OP_JNCF_A16,  0,0,              0,0,
"jnca",    A24,          A24,OP_JNCA_A24,  0,0,              0,0,

"je",      A8,           A8, OP_JE_A8,     0,0,              0,0,
"jef",     A16,          A16,OP_JEF_A16,   0,0,              0,0, 
"jea",     A24,          A24,OP_JEA_A24,   0,0,              0,0, 
"jne",     A8,           A8, OP_JNE_A8,    0,0,              0,0, 
"jnef",    A16,          A16,OP_JNEF_A16,  0,0,              0,0,
"jnea",    A24,          A24,OP_JNEA_A24,  0,0,              0,0,

"jg",      A8,           A8, OP_JG_A8,     0,0,              0,0,
"jgf",     A16,          A16,OP_JGF_A16,   0,0,              0,0,
"jga",     A24,          A24,OP_JGA_A24,   0,0,              0,0,
"jl",      A8,           A8, OP_JL_A8,     0,0,              0,0,
"jlf",     A16,          A16,OP_JLF_A16,   0,0,              0,0,
"jla",     A24,          A24,OP_JLA_A24,   0,0,              0,0,

"jsr",     A24,          A24,OP_JSR_A24,   0,0,              0,0,
"ret",     NA,           0,  OP_RET,       0,0,              0,0,

"pusha",   NA,           0, OP_PUSHA,      0,0,              0,0,
"pushb",   NA,           0, OP_PUSHB,      0,0,              0,0,
"pushc",   NA,           0, OP_PUSHC,      0,0,              0,0, 
"pushs",   NA,           0, OP_PUSHS,      0,0,              0,0,
"pushd",   NA,           0, OP_PUSHD,      0,0,              0,0,
"pushp",   NA,           0, OP_PUSHP,      0,0,              0,0,
"push",    I8,           I8,OP_PUSH_I8,    0,0,              0,0,

"popa",    NA,           0,OP_POPA,        0,0,              0,0,
"popb",    NA,           0,OP_POPB,        0,0,              0,0,
"popc",    NA,           0,OP_POPC,        0,0,              0,0,
"pops",    NA,           0,OP_POPS,        0,0,              0,0,
"popd",    NA,           0,OP_POPD,        0,0,              0,0,
"pop",     NA,           0,OP_POP,         0,0,              0,0,

"clg",     NA,           0,OP_CLG,         0,0,              0,0,
"cle",     NA,           0,OP_CLE,         0,0,              0,0,
"clc",     NA,           0,OP_CLC,         0,0,              0,0,
"clz",     NA,           0,OP_CLZ,         0,0,              0,0,
"clf",     NA,           0,OP_CLF,         0,0,              0,0,

"rst",     NA,           0,OP_RST,         0,0,              0,0,
"htl",     NA,           0,OP_HTL,         0,0,              0,0,

/* keywords */
"db",      DT,           0,0,              0,0,              0,0,
"org",     I8|I16|I24,   0,0,              0,0,              0,0,
"equ",	   I8|I16|I24,   0,0,              0,0,              0,0,
"include", ST,           0,0,              0,0,              0,0,
"incbin",  BIN,          0,0,              0,0,              0,0
};
