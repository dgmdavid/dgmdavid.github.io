/*
	JGASM - Jaguar Virtual Video-Game Assembler
	version 0.1

	by David G. Maziero
	http://dgm.prophp.org/jaguar/
*/

#include "global.h"

/* Type of Arguments */
#define NA      0  /* No Argument at all */
#define LA      1  /* nulL Argument (ie no argument) */
#define RA      2  /* Register A as argument */
#define RB      4  /* Register B as argument */
#define RC      8  /* Register C as argument */
#define I8     16  /* immediate 8-bit value as argument */
#define I16    32  /* immediate 16-bit value as argument */
#define I24    64  /* immediate 24-bit value as argument */
#define BS    128  /* immediate bit set value as argument (0 to 7) */
#define SF    256  /* immediate shift bit value as argument (1 to 8) */
#define ST    512  /* immediate string as argument (quoted) */
#define DT   1024  /* data */
#define A8   2048  /* immediate 8-bit address */
#define A16  4096  /* immediate 8-bit address */
#define A24  8192  /* immediate 8-bit address */
#define BIN 16384  /* include a binary data file */


/* Opcodes */
#define OP_NOP        0x00

#define OP_LDA        0x01
#define OP_LDA_A8     0x02

#define OP_LDB        0x03
#define OP_LDB_A8     0x04

#define OP_LDC        0x05
#define OP_LDC_A8     0x06

#define OP_SETA_I8    0x07
#define OP_SETA_B     0x08
#define OP_SETA_C     0x09

#define OP_SETB_I8    0x0A
#define OP_SETB_A     0x0B
#define OP_SETB_C     0x0C

#define OP_SETC_I8    0x0D
#define OP_SETC_A     0x0E
#define OP_SETC_B     0x0F

#define OP_SETS_I24   0x10
#define OP_SETS_I16   0x11
#define OP_SETS_I8    0x12

#define OP_SETD_I24   0x13
#define OP_SETD_I16   0x14
#define OP_SETD_I8    0x15

#define OP_STA        0x16
#define OP_STA_A8     0x17

#define OP_STB        0x18
#define OP_STB_A8     0x19

#define OP_STC        0x1A
#define OP_STC_A8     0x1B

#define OP_INCA       0x1C
#define OP_INCB       0x1D
#define OP_INCC       0x1E
#define OP_INCS       0x1F
#define OP_INCD       0x20

#define OP_DECA       0x21
#define OP_DECB       0x22
#define OP_DECC       0x23
#define OP_DECS       0x24
#define OP_DECD       0x25

#define OP_ADDA_I8    0x26
#define OP_ADDA_B     0x27
#define OP_ADDA_C     0x28

#define OP_ADDB_I8    0x29
#define OP_ADDB_A     0x2A
#define OP_ADDB_C     0x2B

#define OP_ADDC_I8    0x2C
#define OP_ADDC_A     0x2D
#define OP_ADDC_B     0x2E

#define OP_ADDS_I16   0x2F
#define OP_ADDS_I8    0x30
#define OP_ADDS_A     0x31

#define OP_ADDD_I16   0x32
#define OP_ADDD_I8    0x33
#define OP_ADDD_A     0x34

#define OP_SUBA_I8    0x35
#define OP_SUBA_B     0x36
#define OP_SUBA_C     0x37

#define OP_SUBB_I8    0x38
#define OP_SUBB_A     0x39
#define OP_SUBB_C     0x3A

#define OP_SUBC_I8    0x3B
#define OP_SUBC_A     0x3C
#define OP_SUBC_B     0x3D

#define OP_SUBS_I16   0x3E
#define OP_SUBS_I8    0x3F
#define OP_SUBS_A     0x40

#define OP_SUBD_I16   0x41
#define OP_SUBD_I8    0x42
#define OP_SUBD_A     0x43

#define OP_TSTA       0x44
#define OP_TSTB       0x4C
#define OP_TSTC       0x54

#define OP_ANDA_I8    0x5C
#define OP_ANDA_B     0x5D
#define OP_ANDA_C     0x5E

#define OP_ANDB_I8    0x5F
#define OP_ANDB_A     0x60
#define OP_ANDB_C     0x61

#define OP_ANDC_I8    0x62
#define OP_ANDC_A     0x63
#define OP_ANDC_B     0x64

#define OP_ORA_I8     0x65
#define OP_ORA_B      0x66
#define OP_ORA_C      0x67

#define OP_ORB_I8     0x68
#define OP_ORB_A      0x69
#define OP_ORB_C      0x6A

#define OP_ORC_I8     0x6B
#define OP_ORC_A      0x6C
#define OP_ORC_B      0x6D

#define OP_XORA_I8    0x6E
#define OP_XORA_B     0x6F
#define OP_XORA_C     0x70

#define OP_XORB_I8    0x71
#define OP_XORB_A     0x72
#define OP_XORB_C     0x73

#define OP_XORC_I8    0x74
#define OP_XORC_A     0x75
#define OP_XORC_B     0x76

#define OP_NOTA       0x77
#define OP_NOTB       0x78
#define OP_NOTC       0x79

#define OP_SHLA       0x7A
#define OP_SHLB       0x82
#define OP_SHLC       0x8A

#define OP_SHRA       0x92
#define OP_SHRB       0x9A
#define OP_SHRC       0xA2

#define OP_CMPA_I8    0xAA
#define OP_CMPA_B     0xAB
#define OP_CMPA_C     0xAC
#define OP_CMPB_I8    0xAD
#define OP_CMPB_C     0xAE
#define OP_CMPC_I8    0xAF

#define OP_JMP_A8     0xB0
#define OP_JMPF_A16   0xB1
#define OP_JMPA_A24   0xB2

#define OP_JZ_A8      0xB3
#define OP_JZF_A16    0xB4
#define OP_JZA_A24    0xB5

#define OP_JNZ_A8     0xB6
#define OP_JNZF_A16   0xB7
#define OP_JNZA_A24   0xB8

#define OP_JC_A8      0xB9
#define OP_JCF_A16    0xBA
#define OP_JCA_A24    0xBB

#define OP_JNC_A8     0xBC
#define OP_JNCF_A16   0xBD
#define OP_JNCA_A24   0xBE

#define OP_JE_A8      0xBF
#define OP_JEF_A16    0xC0
#define OP_JEA_A24    0xC1

#define OP_JNE_A8     0xC2
#define OP_JNEF_A16   0xC3
#define OP_JNEA_A24   0xC4

#define OP_JG_A8      0xC5
#define OP_JGF_A16    0xC6
#define OP_JGA_A24    0xC7

#define OP_JL_A8      0xC8
#define OP_JLF_A16    0xC9
#define OP_JLA_A24    0xCA

#define OP_JSR_A24    0xCB
#define OP_RET        0xCC

#define OP_PUSHA      0xCD
#define OP_PUSHB      0xCE
#define OP_PUSHC      0xCF
#define OP_PUSHS      0xD0
#define OP_PUSHD      0xD1
#define OP_PUSHP      0xD2
#define OP_PUSH_I8    0xD3

#define OP_POPA       0xD4
#define OP_POPB       0xD5
#define OP_POPC       0xD6
#define OP_POPS       0xD7
#define OP_POPD       0xD8
#define OP_POP        0xD9

#define OP_CLG        0xDA
#define OP_CLE        0xDB
#define OP_CLC        0xDC
#define OP_CLZ        0xDD
#define OP_CLF        0xDE

#define OP_RST        0xDF
#define OP_HTL        0xE0

#define NUM_OPERANDS  110


#ifndef __OPCODES__
#define __OPCODES__

/* Operator Argument vs Operand relation */
struct SOperand_Relation
{
	word arg;
	byte opcode;
};

/* Operators */
struct SOperand
{
	char *mnemonic;
	word allowed_args;
	struct SOperand_Relation opcodes[3];
};

#endif

extern struct SOperand Operand[NUM_OPERANDS];

