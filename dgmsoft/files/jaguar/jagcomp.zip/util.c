/*
	JGASM - Jaguar Virtual Video-Game Assembler
	version 0.1

	by David G. Maziero
	http://dgm.prophp.org/jaguar/
*/

#include "util.h"


/* MatchOpcode
	parameters:
		check_symbols - TRUE to check for symbol values
		*size         - will be set the size of the opcode and its parameters
		*opcode       - will be set with the opcode index in list
		*m_opcode     - will be set with the opcode argument for opcode
		*value        - the argument with its value parsed to number
	return value:
		return what argument that matches with opcode, or ERROR if the
		argument isn't proper to it.
*/
int MatchOpcode( byte check_symbols, int *size, int *opcode, int *m_opcode, int *value )
{
	int l;
	word allowed_args;

	*size = 0;
	*m_opcode = 0;
	*opcode = 0;
	*value = -1;

	/* find the opcode */
	l = FindOperand( token.mnemonic );
	if( l==ERROR ) return ERROR;
	*opcode = l;

	allowed_args = Operand[l].allowed_args;

	/* operand doesn't need argument and it was not passed */
	if( allowed_args==0 && token.argument[0]=='\0' )
	{
		/* so, operand is just 1 byte long */
		*size = 1;
		return NA;
	}

	/* operand doesn't need argument and it was passed */
	if( allowed_args==0 && token.argument[0]!='\0' )
	{
		return SetError( Err_Msg[ERR_OPERAND_NO_ARG] );
	}

	/* operand needs an argument and it was not passed */
	if( allowed_args>0  && token.argument[0]=='\0' )
	{
		return SetError( Err_Msg[ERR_OPERAND_EXPECT_ARG] );
	}

	/* ok, operand needs an argument and it was passed */

	if( token.argument[1]=='\0' )
	{
		/* operand can accept A register? */
		if( token.argument[0]=='a' )
		{
			if( !(allowed_args & RA) ) return SetError( Err_Msg[ERR_OPERAND_INVALID_ARG] );
			*size = 1;
			*m_opcode = MatchParam( l, RA );
			return RA;
		}
		/* operand can accept B register? */
		if( token.argument[0]=='b' )
		{
			if( !(allowed_args & RB) ) return SetError( Err_Msg[ERR_OPERAND_INVALID_ARG] );
			*size = 1;
			*m_opcode = MatchParam( l, RB );
			return RB;
		}
		/* operand can accept C register? */
		if( token.argument[0]=='c' )
		{
			if( !(allowed_args & RC) ) return SetError( Err_Msg[ERR_OPERAND_INVALID_ARG] );
			*size = 1;
			*m_opcode = MatchParam( l, RC );
			return RC;
		}
	}

	/* operand expects a string value? should be "include" */
	if( allowed_args==ST ) 
	{
		/* this function will not handle this */
		return allowed_args;
	}

	/* operand expects a bin data? should be "incbin" */
	if( allowed_args==BIN ) 
	{
		/* this function will not handle this */
		*size = 0;
		return allowed_args;
	}

	/* operand expects a data value? should be "db" */
	if( allowed_args==DT )
	{
		/* this value will be calculated outside of this function */
		return allowed_args;
	}

	/* operands expects an address value? should be "jump" */
	if( allowed_args==A8 )
	{
		*size = 2;
		return allowed_args;
	}
	if( allowed_args==A16 )
	{
		*size = 3;
		return allowed_args;
	}
	if( allowed_args==A24 )
	{
		*size = 4;
		return allowed_args;
	}
	
	/* parse the value of the argument */
	*value = ParseArgAsValue( token.argument, check_symbols );
	if( *value==ERROR ) return ERROR;

	/* operand expects a bit set value? */
	if( allowed_args==BS )
	{
		/* validate the range */
		if( (*value<0) || (*value>7) ) return SetError( Err_Msg[ERR_OPERAND_BITTEST] );
		/* 2 bytes long */
		*size = 2;
		*m_opcode = MatchParam( l, BS );
		return allowed_args;
	}

	/* operand expects a bit shift value? */
	if( allowed_args==SF )
	{
		/* validate the range */
		if( (*value<1) || (*value>8) ) return SetError( Err_Msg[ERR_OPERAND_BITSHIFT] );
		/* 2 bytes long */
		*size = 2;
		*m_opcode = MatchParam( l, SF );
		return allowed_args;
	}

	/* find the type of the value */
	if( *value<256 )
	{
		*m_opcode = MatchParam( l, I8 );
		if( *m_opcode==ERROR )
		{
			*m_opcode = MatchParam( l, I16 );
			if( *m_opcode==ERROR )
			{
				*m_opcode = MatchParam( l, I24 );
				if( *m_opcode==ERROR ) return SetError( Err_Msg[ERR_OPERAND_INVALID_ARG] );
				*size = 4;
				return I24;
			}
			*size = 3;
			return I16;
		}
		*size = 2;
		return I8;
	} else
	if( *value<65536    ) 
	{
		*m_opcode = MatchParam( l, I16 );
		if( *m_opcode==ERROR )
		{
			*m_opcode = MatchParam( l, I24 );
			if( *m_opcode==ERROR ) return SetError( Err_Msg[ERR_OPERAND_INVALID_ARG] );
			*size = 4;
			return I24;
		}
		*size = 3;
		return I16;
	} else
	if( *value<16777216 ) 
	{
		*m_opcode = MatchParam( l, I24 );
		if( *m_opcode==ERROR ) return SetError( Err_Msg[ERR_OPERAND_INVALID_ARG] );
		*size = 4;
		return I24;
	} else return SetError( Err_Msg[ERR_OPERAND_INVALID_ARG] ); 
	    	  
	return FALSE;
}


/* MatchParam */
int MatchParam( int opcode, word arg )
{
	int l;
	for( l=0; l<3; ++l )
	{
		if( arg==Operand[opcode].opcodes[l].arg ) return l;
	}
	return ERROR;
}


/* FindOperand */
int FindOperand( const char *mnemonic )
{
	int l;
	for( l=0; l<NUM_OPERANDS; ++l )
	{
		if( strcmp( mnemonic, Operand[l].mnemonic )==0 )
		{
			return l;
		}
	}
	return SetError( Err_Msg[ERR_OPERAND_UNDEFINED] );
}


/* AddSymbol */
int AddSymbol( const char *symbol, int value )
{
	if( symbol_count==MAX_SYMBOLS )
	{
		return SetError( Err_Msg[ERR_MAX_SYMBOLS_REACHED] );
	}
	
	if( symbol[1]=='\0' )
	{
		if( symbol[0]=='a' || symbol[0]=='b' || symbol[0]=='c' )
		{
			return SetError( Err_Msg[ERR_INVALID_SYMBOL_NAME] );
		}
	}
	symbol_list[ symbol_count ].name = (char*)malloc( strlen(symbol)+1 );
	strcpy( symbol_list[ symbol_count ].name, symbol );
	symbol_list[ symbol_count ].value = value;
	
	return symbol_count++;
}


/* FindSymbol */
int FindSymbol( const char *symbol )
{
	uint l;
	if( symbol_count==0 ) goto fsymbol_end;
	for( l=0; l<symbol_count; ++l )
	{
		if( strcmp( symbol, symbol_list[l].name )==0 )
		{
			return symbol_list[l].value;
		}
	}
fsymbol_end:
	return SetError( Err_Msg[ERR_UNDEFINED_SYMBOL] );
}


/* AddFile */
int AddFile( const char *name )
{
	int s = strlen( name );
	
	if( file_count==MAX_FILES )
	{
		return SetError( Err_Msg[ERR_MAX_INCLUDES_REACHED] );
	}

	/* TODO: extract file path */
	file_list[ file_count ].name = (char*)malloc( s+1 );
	strcpy( file_list[ file_count ].name, name );

	return file_count++;
}


/* IsAlpha */
int IsAlpha( const char c )
{
	if( c>='a' && c<='z' ) return TRUE;
	return FALSE;
}


/* IsDigit */
int IsDigit( const char c )
{
	if( c>='0' && c<='9' ) return TRUE;
	return FALSE;
}


/* IsHex */
int IsHex( const char c )
{
	if( c==Hex_Notation ) return TRUE;
	return FALSE;
}


/* IsBin */
int IsBin( const char c )
{
	if( c==Bin_Notation ) return TRUE;
	return FALSE;
}


/* HexToWord */
int HexToWord( const char *hex )
{
	uint l = strlen(hex)-1;
	int  value, t;
	value = 0;
	t = 1;
	for( ; l>0; --l )
	{
		if( hex[l]=='0' ) 
		{
			/* do nothing */
		} else
		if( hex[l]=='1' ) value+=1*t; else
		if( hex[l]=='2' ) value+=2*t; else
		if( hex[l]=='3' ) value+=3*t; else
		if( hex[l]=='4' ) value+=4*t; else
		if( hex[l]=='5' ) value+=5*t; else
		if( hex[l]=='6' ) value+=6*t; else
		if( hex[l]=='7' ) value+=7*t; else
		if( hex[l]=='8' ) value+=8*t; else
		if( hex[l]=='9' ) value+=9*t; else
		if( hex[l]=='a' ) value+=10*t; else
		if( hex[l]=='b' ) value+=11*t; else
		if( hex[l]=='c' ) value+=12*t; else
		if( hex[l]=='d' ) value+=13*t; else
		if( hex[l]=='e' ) value+=14*t; else
		if( hex[l]=='f' ) value+=15*t; 
		else return SetError( Err_Msg[ERR_INVALID_HEX_VALUE] );
		t *= 16;
	}
	return value;
}


/* BinToWord */
int BinToWord( const char *binary )
{
	uint l = strlen(binary)-1;
	int  value, t;
	value = 0;
	t = 1;
	for( ; l>0; --l )
	{
		if( binary[l]!='0' && binary[l]!='1' ) 
			return SetError( Err_Msg[ERR_INVALID_BIN_VALUE] );
		if( binary[l]=='1' ) value+=t;
		t *= 2;
	}
	return value;
}


/* ParseArgAsValue */
int ParseArgAsValue( const char *param, byte check_symbols )
{
	/* TODO: evaluate math expressions 
			 must pass on math tokenizer */

	/* a register was passed as parameter? */
	if( param[1]=='\0' )
	{
		if( param[0]=='a' || param[0]=='b' || param[0]=='c' )
		{
			return 0;
		}
	}

	/* does it start with a letter? */
	if( IsAlpha( param[0] ) )
	{
		if( check_symbols==TRUE ) return FindSymbol( param );
		return 0;
	}

	/* quotes? */
	if( param[0]=='"' ) return 0;

	/* does it start with a digit? */
	if( IsDigit( param[0] ) )
	{
		/* so, it's decimal */
		int l;
		for( l=0; param[l]!='\0'; ++l )
		{
			if( !IsDigit( param[l] ) ) 
			{
				SetError( Err_Msg[ERR_INVALID_DEC_VALUE] );
				return ERROR;
			}
		}
		return (word)atoi( param );
	}

	/* start with hex notation? */
	if( IsHex( param[0] ) )
	{
		return HexToWord( param );	
	}

	/* start with binary notation? */
	if( IsBin( param[0] ) )
	{
		return BinToWord( param );
	}

	return SetError( Err_Msg[ERR_INVALID_VALUE] );
}


/* StringToLower */
void StringToLower( char *string )
{
	char *p;
	byte quotes=0;
	for( p=string; *p!='\0'; ++p )
	{
		/* skip text in quotes */
		if( *p=='"' ) quotes=!quotes;
		if( !quotes ) 
		{
			*p = tolower( (byte)*p );
			if( *p=='\t' ) *p=' ';
		}

	}
}


/* ValidateIncludeName */
int ValidateIncludeName( char *param )
{
	/* does it start with quotes? */
	if( param[0]=='"' )
	{
		/* find for quote close */
		int l,s;
		s = strlen(param);
		for( l=1; l<s; ++l ) if( param[l]=='"' ) break;
		if( l<s-1 ) return FALSE;
		/* ok, remove it */
		for( l=0; l<s-1; ++l ) param[l] = param[l+1];
		param[s-2]='\0';
		return TRUE;
	}
	return FALSE;
}


int FixLine( char *tmp_line )
{
	int l1, l2;
	int pos = strlen( tmp_line )-1;
	byte quotes = 0;

	if( pos>=MAX_LINE_SIZE-2 )
	{ 
		cur_line[0]='\0';
		return SetError( Err_Msg[ERR_LINE_TOO_LONG] );
	}

	if( pos>=0 )
	{
		/* cut comments */
		for( l1=0; l1<=pos; ++l1 )
		{
			/* as usual, skip quotes */
			if( tmp_line[l1]=='"' ) quotes=!quotes;
			if( quotes==0 && tmp_line[l1]==';' )
			{
				tmp_line[l1]='\0';
				pos = l1;
				break;
			}
		}
	}
	/* empty line? */
	if( pos<=0 ) 
	{
		tmp_line[0]='\0';
		return FALSE;
	}

	/* cut spaces in front and back */
	for( l1=0;   l1<=pos; ++l1 ) if( tmp_line[l1]!=' '  && tmp_line[l1]!='\t' ) break;
	for( l2=pos; l2>0;    --l2 ) if( tmp_line[l2]!=' '  && tmp_line[l2]!='\t' && tmp_line[l2]!=10 ) break;
	if( l1>l2 ) return FALSE;

	/* copy to cur_line */
	l2 = (l2-l1)+1;
	strcpy( cur_line, tmp_line+l1 );
	cur_line[l2]='\0';
		
	/* convert to lower case */
	StringToLower( cur_line );

	/* scan the string for useless spaces */
scan_again:;
	for( pos=0; pos<l2; ++pos )
	{
		/* as usual, skip quoted strings */
		if( cur_line[pos]=='"' ) quotes=!quotes;
		if( quotes==0 ) {
			/* redundant spaces */
			if( cur_line[pos]==' ' )
			{
				if( cur_line[pos+1]==' '  ||
					cur_line[pos+1]==','  ||
					cur_line[pos+1]=='\0'    )
				{
					int c;
					for( c=pos; c<l2; ++c ) cur_line[c] = cur_line[c+1];
					l2--;
					goto scan_again;
				}
			}
			if( cur_line[pos]==',' && cur_line[pos+1]==' ' )
			{
				int c;
				for( c=pos+1; c<l2; c++ ) cur_line[c] = cur_line[c+1];
				l2--;
				goto scan_again;
			}
		}
	}

	return TRUE;
}