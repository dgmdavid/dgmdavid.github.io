SpaceCombat v0.1
Offical homepage: http://hem.passagen.se/klas82/indext.htm

(c) Klas Tybrandt 2000
klas82@hem3.passagen.se
Oskarshamn, Sweden

OBS! You've to compile the program and run it from the created executable. There isn't
     enought memory to run it in Turbo Pascal. If the program generates runtime error
     200 you've probably a too fast computer. Read the "Pascal section" on my page
     for help.

I use "Glib" in the code for some graphical stuff. "Glib" was made by Mark Rosen.

The game isn't complete. Any programmer is free to modify it, just mention the original
author in the documentation (Klas Tybrandt). 